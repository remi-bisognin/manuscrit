Content of the folders of this archive :
* split : the actual template to use, taking in to account 
  all the setting described in the  cource handout.
* custom : 
   - bibliographiv formats .bst (3 versions in en and fr)
   - the home made  .sty packages (i) fort the thesis front and back-cover
     and for the easy switch between "archivage" and "diffsion" form of the thesis
   - the template file  for the tyhesis meta-data.
   All of these files must be in the working directory (whre the main.tex is)  
   ot  for the  .sty in your  texmf  tree (eg texmf/tex/latex/these/)
       for les .bst dans votre arborescence texmf (in texmf/bibtex/bst/)
* sample : an example of implementation almost complete, that can be compiled,
   showing variis fonctionnalities , including the home made packages
* packages : some package needed to compile  sample. They comme from CTAN, but in case of 
  a not up-to-date version, you have gere the right verions.
* ressources :  additional resources  including :
   - a package for quantum mechanics
   - the flies needed for the use of unicode Greek characters in both  TeWworks and TeXmaker
   - scripts (Window and  Linux) for the batch cleaning  (and possibly compressing)  invalid PDF files
   - logos : some usefull logos.
   
Note : in  custom, a specific folder for the  covers of  PSL thesis
The default format is OK for UPMC/SU, and some minor change could be added 
on demand for other universites (like UPD/USPC and UPSud/UPSaclay)
